<?php
session_start();
if(!isset($_SESSION['librarian_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Dashboard | MyLibrary</title>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root {
    --primary-color: #1a73e8;  
    --secondary-color: #1a73e8; 
    --bg-color: #f5f5f5;        
    --text-color: #333333;
}

body {
    background-color: var(--bg-color);
    color: var(--text-color);
    padding-top: 70px;
}

/* Navbar */
.navbar {
    background-color: var(--primary-color);
}
.navbar .logo, .navbar .nav-link {
    color: #fff !important;
    font-weight: 500;
}
.navbar .nav-link.active {
    background-color: var(--secondary-color);
    color: #000 !important;
    border-radius: 5px;
    font-weight: 600;
}

/* Dashboard Section */
.dashboard-section {
    max-width: 1200px;
    margin: auto;
    padding: 30px 15px;
}
.section-title {
    text-align: center;
    margin-bottom: 10px;
    font-size: 2rem;
    color: var(--primary-color);
}
.dashboard-intro {
    text-align: center;
    margin-bottom: 30px;
    font-size: 1.1rem;
    color: var(--text-color);
}

.dashboard-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.action-card {
    background: #fff;
    padding: 25px 20px;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.12);
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
}
.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.18);
}

.action-card h3 {
    margin-bottom: 12px;
    color: var(--primary-color);
    font-size: 1.5rem;
}
.action-card p {
    margin-bottom: 20px;
    color: var(--text-color);
    font-size: 1rem;
}

.action-card .btn {
    background-color: var(--primary-color);
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 6px;
    font-size: 1rem;
    text-decoration: none;
    transition: background-color 0.3s, color 0.3s;
    display: inline-block;
}
.action-card .btn:hover {
    background-color: var(--secondary-color);
    color: #000;
    text-decoration: none;
}

@media (max-width: 768px) {
    .section-title {
        font-size: 1.7rem;
    }
    .dashboard-intro {
        font-size: 1rem;
    }
    .action-card h3 {
        font-size: 1.3rem;
    }
    .action-card p {
        font-size: 0.95rem;
    }
    .action-card .btn {
        font-size: 0.95rem;
        padding: 8px 18px;
    }
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand logo" href="#">MyLibrary</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
                <li class="nav-item"><a class="nav-link active" href="library_dashboard.php">Library</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<section class="dashboard-section mt-5">
    <h2 class="section-title">Welcome Librarian</h2>
    <p class="dashboard-intro">Manage books, view statistics, and organize the library.</p>

    <div class="dashboard-actions">

        <div class="action-card">
            <h3>Total Books</h3>
            <p><?= $totalBooks ?></p>
            <a href="add_book.php" class="btn">Add Book</a>
        </div>

        <div class="action-card">
            <h3>Manage Books</h3>
            <p>Add, Edit or Delete books</p>
            <a href="Choose.php" class="btn">Manage Books</a>
        </div>

        <div class="action-card">
            <h3>Library Stats</h3>
            <p>Borrowing & reading activity</p>
            <a href="librarystats.php" class="btn">View Stats</a>
        </div>

        <div class="action-card">
            <h3>Add Librarian</h3>
            <p>Create a new librarian account</p>
            <a href="librarian.php" class="btn">Add Librarian</a>
        </div>

    </div>
</section>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
