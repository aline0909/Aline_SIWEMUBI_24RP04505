<?php
session_start();
if(!isset($_SESSION['librarian_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php'; // PDO connection: $pdo

// Fetch all books
try {
    $stmt = $pdo->query("SELECT * FROM books ORDER BY id DESC");
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC); // PDO fetch
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Books | MyLibrary</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root {
    --primary-color: #1a73e8;
    --secondary-color: #fbbc05;
    --bg-color: #f5f5f5;
    --text-color: #333333;
}
body {
    background-color: var(--bg-color);
    color: var(--text-color);
    padding-top: 70px;
}
.navbar { background-color: var(--primary-color); }
.navbar .logo, .navbar .nav-link { color: #fff !important; }
.navbar .nav-link.active { background-color: var(--secondary-color); border-radius: 5px; }
.books-section { max-width: 1200px; margin: auto; padding: 30px 15px; }
table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border-radius: 10px; overflow: hidden; }
th, td { padding: 12px 15px; text-align: center; vertical-align: middle; }
th { background: var(--primary-color); color: #fff; font-weight: 600; }
tr:hover { background: #f1f5fb; }
.btn-edit, .btn-delete { padding: 6px 12px; border-radius: 5px; font-weight: 500; text-decoration: none; display: inline-block; min-width: 70px; }
.btn-edit { background-color: #28a745; color: #fff; }
.btn-edit:hover { background-color: #218838; color: #fff; }
.btn-delete { background-color: #dc3545; color: #fff; }
.btn-delete:hover { background-color: #c82333; color: #fff; }
@media (max-width: 768px) { th, td { font-size: 14px; padding: 8px 10px; } }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand logo" href="index.php">MyLibrary</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
                <li class="nav-item"><a class="nav-link active" href="manageBook.php">Library</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<section class="books-section">
    <h2 class="mb-4 text-center" style="color: var(--primary-color);">Manage Books</h2>
    <div class="table-responsive">
    <table class="table table-striped align-middle">
        <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Year</th>
            <th>Category</th>
            <th>Description</th>
            <th>Modify</th>
        </tr>
        </thead>
        <tbody>
        <?php if(count($books) > 0): ?>
            <?php foreach($books as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= htmlspecialchars($row['author']) ?></td>
                <td><?= htmlspecialchars($row['year']) ?></td>
                <td><?= htmlspecialchars($row['category']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td>
                    <a href="editBook.php?id=<?= $row['id'] ?>" class="btn-edit">Edit</a>
                    <a href="deleteBook.php?id=<?= $row['id'] ?>" class="btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7">No books found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
