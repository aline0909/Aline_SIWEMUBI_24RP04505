<?php
session_start();
if(!isset($_SESSION['librarian_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php'; // PDO connection: $pdo

if(!isset($_GET['id']) || empty($_GET['id'])){
    die("Invalid book ID.");
}
$book_id = intval($_GET['id']);

// Fetch book
try {
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id");
    $stmt->bindValue(':id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);

    if(!$book){
        die("Book not found.");
    }
} catch (PDOException $e){
    die("Database error: " . $e->getMessage());
}

$success = $error = "";

if(isset($_POST['submit'])){
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $year = trim($_POST['year']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);

    if(empty($title) || empty($author) || empty($year) || empty($category)){
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare(
                "UPDATE books 
                 SET title = :title, author = :author, year = :year, category = :category, description = :description
                 WHERE id = :id"
            );
            $stmt->bindValue(':title', $title, PDO::PARAM_STR);
            $stmt->bindValue(':author', $author, PDO::PARAM_STR);
            $stmt->bindValue(':year', $year, PDO::PARAM_INT);
            $stmt->bindValue(':category', $category, PDO::PARAM_STR);
            $stmt->bindValue(':description', $description, PDO::PARAM_STR);
            $stmt->bindValue(':id', $book_id, PDO::PARAM_INT);

            if($stmt->execute()){
                $success = "Book updated successfully!";
                $book['title'] = $title;
                $book['author'] = $author;
                $book['year'] = $year;
                $book['category'] = $category;
                $book['description'] = $description;
            } else {
                $error = "Failed to update book.";
            }
        } catch(PDOException $e){
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Book | MyLibrary</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background:#f4f6f9; }
.edit-card { max-width:600px; margin:auto; border-radius:15px; box-shadow:0 10px 25px rgba(0,0,0,.1); }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">MyLibrary</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
        <li class="nav-item"><a class="nav-link active" href="manageBook.php">Manage Books</a></li>
        <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-5">
    <div class="card edit-card p-4">
        <h4 class="text-center mb-3">Edit Book</h4>

        <?php if($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($book['title']) ?>" placeholder="Book Title *">
            </div>

            <div class="mb-3">
                <input type="text" name="author" class="form-control" value="<?= htmlspecialchars($book['author']) ?>" placeholder="Author *">
            </div>

            <div class="mb-3">
                <input type="number" name="year" class="form-control" value="<?= htmlspecialchars($book['year']) ?>" placeholder="Publication Year *">
            </div>

            <div class="mb-3">
                <input type="text" name="category" class="form-control" value="<?= htmlspecialchars($book['category']) ?>" placeholder="Category *">
            </div>

            <div class="mb-3">
                <textarea name="description" class="form-control" rows="3" placeholder="Description"><?= htmlspecialchars($book['description']) ?></textarea>
            </div>

            <button type="submit" name="submit" class="btn btn-primary w-100">Update Book</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
