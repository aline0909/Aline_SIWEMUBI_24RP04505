<?php
session_start();

if(!isset($_SESSION['librarian_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php'; // Make sure this defines $pdo

if(!isset($_GET['id']) || empty($_GET['id'])){
    die("Invalid book ID.");
}

$book_id = intval($_GET['id']);

try {
    $stmt = $pdo->prepare("DELETE FROM books WHERE id = :id");
    $stmt->bindValue(':id', $book_id, PDO::PARAM_INT);

    if($stmt->execute()){
        header("Location: manageBook.php?msg=deleted");
        exit();
    } else {
        die("Error deleting book.");
    }
} catch(PDOException $e){
    die("Database error: " . $e->getMessage());
}
?>
