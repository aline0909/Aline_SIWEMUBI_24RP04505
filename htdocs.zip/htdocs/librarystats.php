<?php
session_start();
if(!isset($_SESSION['librarian_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php';

$sql = "SELECT 
            b.name AS borrower_name, 
            b.national_id, 
            b.phone, 
            bk.title AS book_title, 
            bb.book_type, 
            bb.borrow_date 
        FROM borrowed_books bb
        JOIN borrowers b ON bb.borrower_id = b.id
        JOIN books bk ON bb.book_id = bk.id
        ORDER BY bb.borrow_date DESC";

$stmt = $pdo->query($sql);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Stats | MyLibrary</title>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    /* Homepage color scheme */
    :root {
        --primary-color: #1a73e8;  
        --bg-color: #f5f5f5;        
        --text-color: #333333;
    }

    body {
        background-color: var(--bg-color);
        color: var(--text-color);
        padding-top: 70px;
    }

    /* Navbar */
    .navbar {
        background-color: var(--primary-color);
    }
    .navbar .logo, .navbar .nav-link {
        color: #fff !important;
    }
    .navbar .nav-link.active {
        background-color: var(--secondary-color);
        border-radius: 5px;
    }

    /* Page title */
    h2 {
        text-align: center;
        margin-bottom: 30px;
        color: var(--primary-color);
    }

    /* Table styling */
    .table-container {
        overflow-x: auto;
        max-width: 95%;
        margin: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    th, td {
        padding: 12px 15px;
        text-align: center;
    }

    th {
        background: var(--primary-color);
        color: #fff;
        font-weight: 600;
    }

    tr:hover {
        background: #f1f5fb;
    }

    @media (max-width: 768px) {
        th, td {
            font-size: 14px;
            padding: 8px 10px;
        }
    }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand logo" href="index.php">MyLibrary</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
                <li class="nav-item"><a class="nav-link active" href="librarystats.php">Library</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<h2>Library Stats & Borrowers</h2>

<div class="table-container">
<table class="table table-striped">
<thead>
<tr>
    <th>Borrower Name</th>
    <th>National ID</th>
    <th>Phone</th>
    <th>Book Title</th>
    <th>Type</th>
    <th>Borrow Date</th>
</tr>
</thead>
<tbody>
<?php if(count($records)>0): ?>
    <?php foreach($records as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['borrower_name']) ?></td>
            <td><?= htmlspecialchars($row['national_id']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['book_title']) ?></td>
            <td><?= htmlspecialchars($row['book_type']) ?></td>
            <td><?= date("d-m-Y H:i", strtotime($row['borrow_date'])) ?></td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
<tr><td colspan="6">No borrowing records found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
