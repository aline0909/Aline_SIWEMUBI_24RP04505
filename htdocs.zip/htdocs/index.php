<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MyLibrary | Home</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f6fa;
    color: #333;
}

/* Navbar */
.navbar {
    background: #1a73e8;
}
.navbar-brand {
    font-size: 28px;
    font-weight: bold;
    color: #fff !important;
}
.nav-link {
    color: #fff !important;
    font-weight: 600;
}
.nav-link:hover,
.nav-link.active {
    color: #ffd600 !important;
}

/* Hero */
.hero-section {
    height: 80vh;
    background: linear-gradient(rgba(26,115,232,0.7), rgba(26,115,232,0.7)),
                url('Downloads/niyo.jpg') center/cover no-repeat;
    display: flex;
    align-items: center;
}
.hero-section h1 {
    font-size: 48px;
    color: #fff;
    text-shadow: 1px 1px 5px rgba(0,0,0,0.5);
}
.hero-section p {
    font-size: 20px;
    color: #f1f1f1;
    text-shadow: 1px 1px 5px rgba(0,0,0,0.5);
}
.hero-btn {
    background: #ffd600;
    color: #111;
    font-weight: bold;
    border-radius: 8px;
}
.hero-btn:hover {
    background: #ffea00;
}

/* Features */
.features {
    padding: 60px 0;
    background: #f0f4ff;
}
.feature-box {
    background: #fff;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.12);
    transition: transform 0.3s, box-shadow 0.3s;
}
.feature-box:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.18);
}
.feature-box img {
    width: 80px;
    margin-bottom: 15px;
}
.feature-box h4 {
    font-size: 1.3rem;
    margin-bottom: 12px;
    color: #1a73e8;
}

/* Footer */
.footer {
    background: #1a73e8;
    color: #fff;
    text-align: center;
    padding: 18px 0;
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="index.php">MyLibrary</a>

    <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="menu">
      <ul class="navbar-nav ms-auto gap-3">
        <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
        <li class="nav-item"><a class="nav-link" href="Library.php">Library</a></li>

        <?php if(isset($_SESSION['librarian_id'])): ?>
            <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero-section">
  <div class="container text-center">
    <h1>Welcome to MyLibrary 📚</h1>
    <p>Your gateway to reading, borrowing, and managing books with ease.</p>
    <a href="books.php" class="btn hero-btn px-4 py-2">Explore Books</a>
  </div>
</section>

<!-- Features Section -->
<section class="features">
  <div class="container">
    <h2 class="text-center mb-5 text-primary">Why Choose MyLibrary?</h2>

    <div class="row g-4 justify-content-center">

      <div class="col-md-4">
        <div class="feature-box text-center">
          <img src="images/student-reading.png" alt="Read Anytime">
          <h4>📘 Read Anytime</h4>
          <p>Access thousands of books anytime and anywhere.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="feature-box text-center">
          <img src="images/student-borrow.png" alt="Borrow Easily">
          <h4>📚 Borrow Easily</h4>
          <p>Borrow books with one click and track history.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="feature-box text-center">
          <img src="images/fast-learning.png" alt="Fast & Simple">
          <h4>⚡ Fast & Simple</h4>
          <p>Designed for speed, comfort, and productivity.</p>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- Footer -->
<footer class="footer">
  <p>© <?php echo date("Y"); ?> | robertniyonkuru@gmail.com | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
