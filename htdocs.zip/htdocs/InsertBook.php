<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if(!isset($_SESSION['librarian_id'])){
    header("Location: login.php");
    exit();
}

// PDO connection
include 'db.php';  // Make sure $pdo is defined in db.php

$success = $error = "";

if (isset($_POST['submit'])) {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $year = trim($_POST['year']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);

    try {
        $stmt = $pdo->prepare("INSERT INTO books (title, author, year, category, description) 
                               VALUES (:title, :author, :year, :category, :description)");
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':author', $author);
        $stmt->bindParam(':year', $year);
        $stmt->bindParam(':category', $category);
        $stmt->bindParam(':description', $description);

        if($stmt->execute()){
            $success = "Book added successfully.";
        } else {
            $error = "Error adding book.";
        }
    } catch(PDOException $e){
        $error = "Database Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Books | MyLibrary</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background-color:#f5f5f5; padding-top:70px; color:#333; }
.navbar { background-color: #1a73e8; }
.navbar .logo, .navbar .nav-link { color: #fff !important; }
.navbar .nav-link.active { background-color: #fbbc05; border-radius:5px; }
.books-section { max-width:700px; margin:auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 0 15px rgba(0,0,0,0.1); }
.book-form .form-control { margin-bottom:15px; }
.btn-primary { background-color:#1a73e8; border-color:#1a73e8; }
.btn-primary:hover { background-color:#fbbc05; border-color:#fbbc05; }
.alert-success { background-color:#d4edda; color:#155724; }
.alert-danger { background-color:#f8d7da; color:#721c24; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top">
<div class="container">
<a class="navbar-brand logo" href="#">MyLibrary</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
<li class="nav-item"><a class="nav-link active" href="insertbook.php">Library</a></li>
<li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
</ul>
</div>
</div>
</nav>

<section class="books-section mt-5">
<h2 class="mb-4 text-center">Add a New Book</h2>

<?php if($success): ?>
<div class="alert alert-success"><?= $success ?></div>
<?php elseif($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form action="" method="post" class="book-form">
<input type="text" name="title" class="form-control" placeholder="Book Title *" required>
<input type="text" name="author" class="form-control" placeholder="Author Name *" required>
<input type="number" name="year" class="form-control" placeholder="Publication Year *" required>
<input type="text" name="category" class="form-control" placeholder="Category *" required>
<textarea name="description" class="form-control" placeholder="Short Description"></textarea>
<button type="submit" name="submit" class="btn btn-primary w-100">Add Book</button>
</form>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
