<?php
session_start();
include 'db.php'; // Centralized DB connection

if(!isset($_GET['book_id'])){
    die("Book not specified.");
}
$book_id = intval($_GET['book_id']);

$success = $error = '';

if(isset($_POST['borrow'])) {
    $name = trim($_POST['name']);
    $national_id = trim($_POST['national_id']);
    $phone = trim($_POST['phone']);
    $book_type = $_POST['book_type'];

    if(empty($name) || empty($national_id) || empty($phone)) {
        $error = "Please fill all fields.";
    } else {

        // Check borrower
        $stmt = $conn->prepare("SELECT id FROM borrowers WHERE national_id = ?");
        $stmt->bindValue(1, $national_id, PDO::PARAM_STR);
        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);

        if($res) {
            $borrower_id = $res['id'];
        } else {
            $stmt2 = $conn->prepare(
                "INSERT INTO borrowers (name, national_id, phone) VALUES (?,?,?)"
            );
            $stmt2->bindValue(1, $name);
            $stmt2->bindValue(2, $national_id);
            $stmt2->bindValue(3, $phone);
            $stmt2->execute();
            $borrower_id = $conn->lastInsertId();
        }

        // Insert borrow record
        $stmt3 = $conn->prepare(
            "INSERT INTO borrowed_books (borrower_id, book_id, book_type) VALUES (?,?,?)"
        );
        $stmt3->bindValue(1, $borrower_id, PDO::PARAM_INT);
        $stmt3->bindValue(2, $book_id, PDO::PARAM_INT);
        $stmt3->bindValue(3, $book_type, PDO::PARAM_STR);

        if($stmt3->execute()){
            $success = "Successfully registered and recorded as '$book_type'.";
        } else {
            $error = "Failed to record borrowing.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Borrow / Purchase Book</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background:#f5f6fa;
}
.form-container {
    max-width: 460px;
    background:#fff;
    padding:30px;
    border-radius:14px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
}
.form-container h2 {
    font-weight:700;
    color:#1a73e8;
}
.btn-primary {
    background:#1a73e8;
    border:none;
}
.btn-primary:hover {
    background:#155bb5;
}
.back-link {
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#1a73e8;
}
.back-link:hover {
    text-decoration:underline;
}
</style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="form-container w-100">

        <h2 class="text-center mb-4">Borrow / Purchase Book</h2>

        <?php if($success): ?>
            <div class="alert alert-success text-center"><?= $success ?></div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger text-center"><?= $error ?></div>
        <?php endif; ?>

        <form action="" method="post">
            <div class="mb-3">
                <input type="text" name="name" class="form-control"
                       placeholder="Full Name" required>
            </div>

            <div class="mb-3">
                <input type="text" name="national_id" class="form-control"
                       placeholder="National ID (16 digits)" maxlength="16" required>
            </div>

            <div class="mb-3">
                <input type="tel" name="phone" class="form-control"
                       placeholder="Phone Number" required>
            </div>

            <div class="mb-3">
                <select name="book_type" class="form-select" required>
                    <option value="">-- Select Option --</option>
                    <option value="Borrow">Borrow</option>
                    <option value="Purchase">Purchase</option>
                </select>
            </div>

            <button type="submit" name="borrow" class="btn btn-primary w-100">
                Submit
            </button>

            <a href="index.php" class="back-link">← Back Home</a>
        </form>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
