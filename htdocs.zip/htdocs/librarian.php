<?php
session_start();
include 'db.php'; // Use centralized PDO connection

$signup_error = $signup_success = "";

if(isset($_POST['signup'])) {
    $fullname = trim($_POST['fullname']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if(empty($fullname) || empty($username) || empty($password)){
        $signup_error = "Please fill all fields for signup.";
    } else {
        // Check if username exists
        try {
            $stmt = $pdo->prepare("SELECT * FROM librarians WHERE username = ?");
            $stmt->bindValue(1, $username, PDO::PARAM_STR);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if($user){
                $signup_error = "Username already exists.";
            } else {
                // Insert new librarian
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt2 = $pdo->prepare("INSERT INTO librarians (fullname, username, password) VALUES (?, ?, ?)");
                $stmt2->bindValue(1, $fullname, PDO::PARAM_STR);
                $stmt2->bindValue(2, $username, PDO::PARAM_STR);
                $stmt2->bindValue(3, $hash, PDO::PARAM_STR);

                if($stmt2->execute()){
                    $signup_success = "Signup successful! You can login now.";
                } else {
                    $signup_error = "Error: Could not register user.";
                }
            }
        } catch(PDOException $e){
            $signup_error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Signup Librarian | MyLibrary</title>
<link rel="stylesheet" href="style.css">
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #e0f0ff, #f7faff);
    margin: 0;
    padding: 0;
}
.container {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    gap: 40px;
    padding: 80px 20px;
    flex-wrap: wrap;
}
.form-box {
    background: #fff;
    padding: 35px 30px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    width: 340px;
    text-align: center;
}
.form-box h2 {
    text-align: center;
    margin-bottom: 25px;
    font-size: 24px;
    color: #1a1a1a;
}
.form-box input[type="text"],
.form-box input[type="password"] {
    width: 100%;
    padding: 14px;
    margin: 12px 0;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 16px;
}
.form-box input[type="text"]:focus,
.form-box input[type="password"]:focus {
    border-color: #1a73e8;
    box-shadow: 0 0 6px rgba(26, 115, 232, 0.4);
    outline: none;
}
.btn {
    width: 100%;
    padding: 14px;
    margin-top: 15px;
    background: #1a73e8;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 16px;
}
.btn:hover {
    background: #155bb5;
}
p.success {
    color: #28a745;
    font-weight: 600;
    margin-bottom: 10px;
}
p.error {
    color: #dc3545;
    font-weight: 600;
    margin-bottom: 10px;
}
a.login-link {
    display:block;
    text-align:center;
    margin-top:15px;
    color:red;
    text-decoration:none;
    font-weight:600;
}
a.login-link:hover {
    text-decoration: underline;
}
@media (max-width: 768px) {
    .container {
        flex-direction: column;
        align-items: center;
        padding: 50px 10px;
    }
    .form-box {
        width: 90%;
    }
}
</style>
</head>
<body>

<div class="container">
    <div class="form-box">
        <h2>Signup Librarian</h2>
        <?php if($signup_success) echo "<p class='success'>$signup_success</p>"; ?>
        <?php if($signup_error) echo "<p class='error'>$signup_error</p>"; ?>
        <form action="" method="post">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" name="signup" value="Signup" class="btn">
        </form>
        <a href="login.php" class="login-link">Already have an account? Login</a>
    </div>
</div>

</body>
</html>
