<?php
session_start();
include 'db.php'; // Use centralized PDO connection

try {
    $sql = "SELECT * FROM books ORDER BY title ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching books: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Books | MyLibrary</title>
<link rel="stylesheet" href="style.css">
<style>
/* General colors */
:root {
    --primary-color: #1a73e8;
    --secondary-color: #fbbc05;
    --bg-color: #f5f5f5;
    --text-color: #333;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: var(--bg-color);
    color: var(--text-color);
    margin: 0;
    padding: 0;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: var(--primary-color);
    padding: 15px 30px;
    color: #fff;
    position: sticky;
    top: 0;
    z-index: 100;
}
.navbar .logo {
    font-size: 22px;
    font-weight: 700;
}
.navbar .menu {
    list-style: none;
    display: flex;
    gap: 20px;
    margin: 0;
    padding: 0;
}
.navbar .menu li a {
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}
.navbar .menu li a:hover {
    text-decoration: underline;
}

/* Books section */
.books-section {
    padding: 60px 20px;
    max-width: 1200px;
    margin: auto;
}
.section-title {
    text-align: center;
    font-size: 32px;
    margin-bottom: 40px;
}
.books-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 25px;
}
.book-card {
    background: #fff;
    padding: 20px;
    width: 220px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    text-align: center;
    transition: transform 0.3s, box-shadow 0.3s;
}
.book-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
.book-cover {
    width: 100%;
    height: auto;
    border-radius: 8px;
    margin-bottom: 15px;
}
.book-title {
    font-size: 18px;
    margin-bottom: 8px;
}
.book-title a {
    text-decoration: none;
    color: var(--text-color);
}
.book-title a:hover {
    color: var(--primary-color);
}
.book-author {
    font-size: 14px;
    color: #555;
    margin-bottom: 12px;
}
.btn {
    display: inline-block;
    padding: 10px 15px;
    background: var(--primary-color);
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
}
.btn:hover { background: #155bb5; }

/* Responsive */
@media (max-width: 768px) {
    .books-container {
        justify-content: center;
    }
    .book-card {
        width: 90%;
    }
}
</style>
</head>
<body>

<nav class="navbar">
    <div class="logo">MyLibrary</div>
    <ul class="menu">
        <li><a href="index.php">Home</a></li>
        <li><a href="InsertBook.php">Library</a></li>
        <?php if(isset($_SESSION['librarian_id'])): ?>
            <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['librarian_name']) ?>)</a></li>
        <?php else: ?>
            <li><a href="login.php">Login</a></li>
        <?php endif; ?>
    </ul>
</nav>

<section class="books-section">
    <h2 class="section-title">Available Books</h2>
    <div class="books-container">

        <?php if(count($books) > 0): ?>
            <?php foreach($books as $book): ?>
                <div class="book-card">
                    <img src="https://via.placeholder.com/150" alt="Book Cover" class="book-cover">
                    <h3 class="book-title">
                        <a href="bookdetails.php?book_id=<?= htmlspecialchars($book['id']) ?>">
                            <?= htmlspecialchars($book['title']) ?>
                        </a>
                    </h3>
                    <p class="book-author">by <?= htmlspecialchars($book['author']) ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align:center;">No books available at the moment.</p>
        <?php endif; ?>

    </div>
</section>

</body>
</html>
